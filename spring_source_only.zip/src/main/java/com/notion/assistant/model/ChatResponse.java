package com.notion.assistant.model;

import java.util.Map;

public class ChatResponse {
    private String response;
    private Map<String, Object> error;

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public Map<String, Object> getError() {
        return error;
    }

    public void setError(Map<String, Object> error) {
        this.error = error;
    }
} 