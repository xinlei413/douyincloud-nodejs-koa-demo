package com.notion.assistant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotionAssistantApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotionAssistantApplication.class, args);
    }
} 