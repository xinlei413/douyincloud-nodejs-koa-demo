package com.notion.assistant.service;

import com.notion.assistant.model.ChatRequest;
import com.notion.assistant.model.ChatResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Service
public class CozeApiService {
    private static final Logger logger = LoggerFactory.getLogger(CozeApiService.class);
    private static final String COZE_API_URL = "https://api.coze.cn/open/chat";
    
    private final RestTemplate restTemplate;
    
    public CozeApiService() {
        this.restTemplate = new RestTemplate();
    }
    
    public ChatResponse sendMessageToCoze(ChatRequest request) {
        logger.info("Sending request to Coze API with bot_id: {}", request.getBot_id());
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", "Bearer " + request.getToken());
        
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("bot_id", request.getBot_id());
        requestBody.put("messages", request.getMessages());
        requestBody.put("temperature", 0.7);
        requestBody.put("top_p", 0.9);
        requestBody.put("presence_penalty", 0);
        requestBody.put("frequency_penalty", 0);
        
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(requestBody, headers);
        
        try {
            logger.info("Request payload: {}", requestBody);
            ResponseEntity<ChatResponse> response = restTemplate.postForEntity(COZE_API_URL, entity, ChatResponse.class);
            logger.info("Received response from Coze API: {}", response.getBody());
            return response.getBody();
        } catch (Exception e) {
            logger.error("Error calling Coze API: ", e);
            ChatResponse errorResponse = new ChatResponse();
            Map<String, Object> error = new HashMap<>();
            error.put("message", e.getMessage());
            errorResponse.setError(error);
            return errorResponse;
        }
    }
} 